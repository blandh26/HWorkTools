﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_Util
{
    public static class FtpConfig
    {
        public static string ip { get; set; }
        public static string name { get; set; }
        public static string psw { get; set; }
        public static string path { get; set; }
        public static bool isShwo { get; set; }
    }
}
